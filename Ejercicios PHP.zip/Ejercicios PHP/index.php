<html lang="es">
<head>
<title>Ejercicios en PHP</title>
<meta charset="uft-8"/>
</head>
<body style="background:url('Hatsune-Miku.jpg') no-repeat bottom left" width=80% bgcolor="black" border="2">
<h1>VARIABLES</h1>
<a href="Ejercicio1.php">Ejercicio 1</a>
<a href="Ejercicio2.php">Ejercicio 2</a>
<a href="Ejercicio3.php">Ejercicio 3</a>
<a href="Ejercicio4.php">Ejercicio 4</a>
<a href="Ejercicio5.php">Ejercicio 5</a>
</body>
</html>